--
-- Banco de dados: `astro`
--
CREATE DATABASE IF NOT EXISTS `astro` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `astro`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `aditivos`
--

CREATE TABLE `aditivos` (
  `ID_ADITIVO` int(6) NOT NULL,
  `ID_CONTRATO` int(6) NOT NULL,
  `NR_ADITIVO` int(6) NOT NULL,
  `DT_INICIO` date NOT NULL,
  `DT_TERMINO` date NOT NULL,
  `VL_PESO` decimal(13,2) DEFAULT NULL,
  `VL_TOTAL` decimal(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `baixas`
--

CREATE TABLE `baixas` (
  `ID_BAIXA` int(6) NOT NULL,
  `ID_CAIXA` int(6) NOT NULL,
  `ID_LANCAMENTO` int(6) DEFAULT NULL,
  `ID_CONTRATO` int(6) DEFAULT NULL,
  `ID_TRANSPORTE` int(6) DEFAULT NULL,
  `ID_DESPESA` int(6) DEFAULT NULL,
  `BAI_DATA` date DEFAULT NULL,
  `BAI_DESCRICAO` varchar(200) DEFAULT NULL,
  `TP_BAIXA` int(1) NOT NULL,
  `BAI_VALOR` decimal(13,2) NOT NULL,
  `ST_BAIXA` int(1) NOT NULL,
  `ID_FUNCIONARIO` int(6) NOT NULL,
  `ID_PERIODO` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `baixas`
--

INSERT INTO `baixas` (`ID_BAIXA`, `ID_CAIXA`, `ID_LANCAMENTO`, `ID_CONTRATO`, `ID_TRANSPORTE`, `ID_DESPESA`, `BAI_DATA`, `BAI_DESCRICAO`, `TP_BAIXA`, `BAI_VALOR`, `ST_BAIXA`, `ID_FUNCIONARIO`, `ID_PERIODO`) VALUES
(1, 0, NULL, NULL, 2, NULL, NULL, 'Transporte: 2; Transporte agendado para as 07:30 com pausa para o almoÃ§o', 0, '281.57', 0, 1, 12),
(2, 1, NULL, NULL, 3, NULL, '2016-12-07', 'Transporte: 3; Viagem agendada para as 13:30 com retorno previsto para as 16:00', 0, '314.60', 1, 1, 12),
(3, 0, NULL, NULL, 5, NULL, NULL, 'Transporte: 5; Necessita de ajudante na viagem e pausa pro almoÃ§o. Agendada para as 05:00', 0, '395.29', 0, 8, 12),
(4, 0, NULL, NULL, 6, NULL, NULL, 'Transporte: 6; Viagem agendada para as 23:00. Seguro para carga acionado.', 0, '141.10', 0, 8, 12),
(5, 0, NULL, NULL, 7, NULL, NULL, 'Transporte: 7; Viagem agendada para as 15:00. Motorista novo em treinamento.', 0, '422.67', 0, 8, 12),
(10, 1, NULL, NULL, NULL, 7, '2016-12-06', 'Despesa: 7; Pagamento realizado em dinheiro.', 1, '235.00', 1, 9, 12),
(13, 1, NULL, NULL, NULL, 17, '2016-12-06', 'Despesa: 17; Troca de Pneu.', 1, '70.00', 1, 9, 12),
(15, 1, 1, NULL, NULL, NULL, '2016-12-06', 'LanÃ§amento: 1; Documento: Dinheiro em EspÃ©cie; Valor que havia sido retirado do caixa para fins pessoais.', 4, '350.00', 1, 9, 12),
(18, 0, NULL, NULL, NULL, 21, NULL, 'Despesa: 21 - AlmoÃ§o do funcionÃ¡rio custeado pela empresa por motivo de viagem tÃ©cnica.', 1, '25.00', 0, 1, 12),
(19, 1, NULL, NULL, NULL, 22, '2016-12-06', 'Despesa: 22 - Canetas, lapiseiras, borrachas e cadernos para anotaÃ§Ãµes.', 1, '39.90', 1, 1, 12),
(20, 1, NULL, NULL, NULL, 23, '2016-12-06', 'Despesa: 23 - Troca de bomba injetora + mÃ£o de obra.', 1, '800.00', 1, 1, 12),
(21, 2, 2, NULL, NULL, NULL, '2016-12-06', 'LanÃ§amento: 2; Documento: DOC-289877; AplicaÃ§Ã£o para reserva de capital.', 4, '5000.00', 1, 1, 12),
(22, 1, 3, NULL, NULL, NULL, '2016-12-06', 'LanÃ§amento: 3; Documento: S/N; Valor para despesas com viagem.', 3, '100.00', 1, 1, 12),
(23, 1, 4, 1, NULL, NULL, '2016-12-06', 'LanÃ§amento: 4; Documento: CH-236176; Adiantamento contratual.', 2, '15000.00', 1, 1, 12),
(24, 0, NULL, NULL, 17, NULL, NULL, 'Transporte: 17; BalanÃ§a demorou 30 minutos para avaliar o peso. TÃ©cnico Toledo ciente.', 0, '398.82', 0, 1, 12),
(25, 0, NULL, NULL, NULL, 24, NULL, 'Despesa: 24 - ALMOÃ‡O', 1, '25.00', 0, 8, 12),
(26, 1, 5, NULL, NULL, NULL, '2016-12-07', 'LanÃ§amento: 5; Documento: DOC - 1321356; TransferÃªncia referente a parcela do caminhÃ£o', 3, '953.25', 1, 8, 12),
(27, 1, NULL, NULL, NULL, 25, '2016-11-30', 'Despesa: 25 - Conserto do motor e do eixo traseiro.', 1, '2780.00', 1, 8, 11),
(28, 1, NULL, NULL, NULL, 26, '2016-10-15', 'Despesa: 26 - Foi necessÃ¡rio trocar todos os pneus, pois estavam gastos.', 1, '1450.00', 1, 9, 10);

-- --------------------------------------------------------

--
-- Estrutura para tabela `caixa`
--

CREATE TABLE `caixa` (
  `ID_CAIXA` int(6) NOT NULL,
  `CAI_BANCO` varchar(80) NOT NULL,
  `CAI_AGENCIA` varchar(7) DEFAULT NULL,
  `CAI_CONTA` varchar(14) DEFAULT NULL,
  `CAI_NOME` varchar(80) NOT NULL,
  `CAI_STATUS` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `caixa`
--

INSERT INTO `caixa` (`ID_CAIXA`, `CAI_BANCO`, `CAI_AGENCIA`, `CAI_CONTA`, `CAI_NOME`, `CAI_STATUS`) VALUES
(0, 'Desconhecido', 'XXXX', 'XXXX', 'Desconhecido', 1),
(1, 'Banco do Brasil', '1020-1', '2035-2', 'BB - Conta Corrente', 1),
(2, 'SANTANDER', '0307', '01078932-1', 'SANTANDER POUPANÃ‡A', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `caixas_saldos`
--

CREATE TABLE `caixas_saldos` (
  `ID_CAIXA_SALDO` int(6) NOT NULL,
  `ID_CAIXA` int(6) NOT NULL,
  `VL_SALDO` decimal(13,2) DEFAULT NULL,
  `PER_ANO` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `caixas_saldos`
--

INSERT INTO `caixas_saldos` (`ID_CAIXA_SALDO`, `ID_CAIXA`, `VL_SALDO`, `PER_ANO`) VALUES
(1, 1, '10000.00', 2016),
(2, 2, '800.00', 2016),
(3, 1, '10000.00', 2015),
(4, 2, '800.00', 2015);

-- --------------------------------------------------------

--
-- Estrutura para tabela `cargos`
--

CREATE TABLE `cargos` (
  `ID_CARGO` int(6) NOT NULL,
  `CAR_NOME` varchar(80) NOT NULL,
  `CAR_STATUS` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `cargos`
--

INSERT INTO `cargos` (`ID_CARGO`, `CAR_NOME`, `CAR_STATUS`) VALUES
(1, 'Motorista', 1),
(3, 'Auxiliar Administrativo', 1),
(4, 'EstagiÃ¡rio Administrativo', 1),
(5, 'Jovem Aprendiz', 1),
(6, 'MecÃ¢nico', 1),
(7, 'Auxiliar MecÃ¢nico', 1),
(8, 'Contador', 0),
(9, 'Gerente', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `contratos`
--

CREATE TABLE `contratos` (
  `ID_CONTRATO` int(6) NOT NULL,
  `ID_TP_CONTRATO` int(6) NOT NULL,
  `NR_CONTRATO` varchar(6) NOT NULL,
  `CON_DT_INICIO` date NOT NULL,
  `CON_DT_FIM` date NOT NULL,
  `CON_VL_PESO` decimal(13,2) DEFAULT NULL,
  `CON_VALOR` decimal(13,2) DEFAULT NULL,
  `CON_PARTIDA` varchar(80) DEFAULT NULL,
  `CON_DESTINO` varchar(80) DEFAULT NULL,
  `CON_DESCRICAO` varchar(200) DEFAULT NULL,
  `CON_STATUS` int(1) NOT NULL DEFAULT '1',
  `ID_PESSOA` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `contratos`
--

INSERT INTO `contratos` (`ID_CONTRATO`, `ID_TP_CONTRATO`, `NR_CONTRATO`, `CON_DT_INICIO`, `CON_DT_FIM`, `CON_VL_PESO`, `CON_VALOR`, `CON_PARTIDA`, `CON_DESTINO`, `CON_DESCRICAO`, `CON_STATUS`, `ID_PESSOA`) VALUES
(1, 1, '2', '2016-05-10', '2016-12-10', '0.00', '1250.00', 'Avenida Alceu Carvalho, 25 - Centro', 'Rua Miguel Dantas, 10 - Moreira Cesar', 'Carregar Placas de AÃ§o do DepÃ³sito no centro atÃ© a FÃ¡brica em Moreira CÃ©sar.', 1, 4),
(2, 1, '4', '2016-01-14', '2016-12-14', '0.00', '3500.00', 'Rua Doutor Emilio Patriota, 10 - Cidade Jardim - Pinda', 'Avenida Dr Fontes Junior, 25 - Gurilandia - TaubatÃ©', 'Viagens entre pinda e taubatÃ©, transportando chapas de aÃ§o 1020.', 1, 4),
(3, 2, '1', '2016-12-01', '2016-12-31', '15.73', '0.00', 'Avenida dos Cravos NÂº 13 Jdm das Flores Campos do JordÃ£o/SP', 'Estrada dos Pardais NÂº 89 Distrito Industrial Pindamonhangaba/SP', 'Viagem de entre Campos e Pinda, transportando sucata.', 1, 1),
(4, 1, '4', '2016-12-01', '2017-06-30', '0.00', '120000.00', 'LaminaÃ§Ã£o I', 'LaminaÃ§Ã£o II', '', 1, 3),
(5, 2, '5', '2016-09-01', '2017-06-30', '13.80', '0.00', 'Sucataria', 'Aciaria Principal', 'Transporte de sucata do posto de coleta atÃ© a aciaria. VerificaÃ§Ã£o com tÃ©c. Toledo.', 1, 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `despesas`
--

CREATE TABLE `despesas` (
  `ID_DESPESA` int(6) NOT NULL,
  `ID_VEICULO` int(6) DEFAULT NULL,
  `DES_DATA` date DEFAULT NULL,
  `DES_NOTA` varchar(8) DEFAULT NULL,
  `DES_DESCRICAO` varchar(80) DEFAULT NULL,
  `ID_PESSOA` int(6) NOT NULL,
  `ID_TP_DESPESA` int(6) NOT NULL,
  `ID_FUNCIONARIO` int(6) NOT NULL,
  `ID_PERIODO` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `despesas`
--

INSERT INTO `despesas` (`ID_DESPESA`, `ID_VEICULO`, `DES_DATA`, `DES_NOTA`, `DES_DESCRICAO`, `ID_PESSOA`, `ID_TP_DESPESA`, `ID_FUNCIONARIO`, `ID_PERIODO`) VALUES
(7, 1, '2016-12-06', 'NF-84585', 'Pagamento realizado em dinheiro.', 2, 3, 10, 12),
(17, 3, '2016-12-06', 'NF-87675', 'Troca de Pneu.', 6, 3, 11, 12),
(21, 0, '2016-12-06', 'NF-83929', 'AlmoÃ§o do funcionÃ¡rio custeado pela empresa por motivo de viagem tÃ©cnica.', 5, 1, 8, 12),
(22, 0, '2016-12-06', 'NF-39109', 'Canetas, lapiseiras, borrachas e cadernos para anotaÃ§Ãµes.', 6, 4, 9, 12),
(23, 2, '2016-12-06', 'NF-12918', 'Troca de bomba injetora + mÃ£o de obra.', 7, 3, 11, 12),
(24, 0, '2016-12-07', 'NF456546', 'ALMOÃ‡O', 5, 1, 11, 12),
(25, 3, '2016-11-07', 'NF798465', 'Conserto do motor e do eixo traseiro.', 7, 3, 8, 11),
(26, 2, '2016-10-15', 'NF-53253', 'Foi necessÃ¡rio trocar todos os pneus, pois estavam gastos.', 6, 3, 10, 10);

-- --------------------------------------------------------

--
-- Estrutura para tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `ID_FUNCIONARIO` int(6) NOT NULL,
  `FUN_NOME` varchar(80) NOT NULL,
  `FUN_SOBRENOME` varchar(80) NOT NULL,
  `FUN_CPF` varchar(11) NOT NULL,
  `FUN_CNH` varchar(11) DEFAULT NULL,
  `FUN_ENDERECO` varchar(80) DEFAULT NULL,
  `FUN_DTNASC` date NOT NULL,
  `FUN_NUMERO` varchar(6) DEFAULT NULL,
  `FUN_BAIRRO` varchar(45) NOT NULL,
  `FUN_CIDADE` varchar(80) DEFAULT NULL,
  `FUN_UF` char(2) DEFAULT NULL,
  `FUN_CEP` varchar(8) DEFAULT NULL,
  `FUN_FONE1` varchar(15) DEFAULT NULL,
  `FUN_FONE2` varchar(15) DEFAULT NULL,
  `FUN_EMAIL` varchar(80) NOT NULL,
  `FUN_SENHA` varchar(35) NOT NULL,
  `FUN_STATUS` int(1) NOT NULL DEFAULT '1',
  `FUN_ACESSO` int(1) NOT NULL,
  `ID_CARGO` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `funcionarios`
--

INSERT INTO `funcionarios` (`ID_FUNCIONARIO`, `FUN_NOME`, `FUN_SOBRENOME`, `FUN_CPF`, `FUN_CNH`, `FUN_ENDERECO`, `FUN_DTNASC`, `FUN_NUMERO`, `FUN_BAIRRO`, `FUN_CIDADE`, `FUN_UF`, `FUN_CEP`, `FUN_FONE1`, `FUN_FONE2`, `FUN_EMAIL`, `FUN_SENHA`, `FUN_STATUS`, `FUN_ACESSO`, `ID_CARGO`) VALUES
(1, 'Administrador', 'Admin', '99999999999', '99999999999', 'Rua Vinte e Um', '1980-01-01', '21', 'Jardim Racional', 'SÃ£o Paulo', 'SP', '99999999', '(99) 9999-9999', '(99) 99999-9999', 'admin@astro.com', '202cb962ac59075b964b07152d234b70', 1, 3, 9),
(8, 'Adriano', 'SilvÃ©rio Damas de Oliveira', '39748225852', '46578913221', 'Rua das Grevilhas', '1991-04-04', '315', 'City Gardem', 'Pindamonhangaba', 'SP', '12403210', '(12) 3642-2222', '(12) 99764-0000', 'adriano@astro.com', '202cb962ac59075b964b07152d234b70', 1, 3, 3),
(9, 'Thiago', 'Oliveira Teberga', '41424380855', '10203040501', 'Rua Dona Emilia Imediato', '1994-03-19', '208', 'Boa Vista', 'Pindamonhangaba', 'SP', '12401040', '(12) 3522-9408', '(12) 99118-1988', 'thiago@astro.com', '202cb962ac59075b964b07152d234b70', 1, 3, 3),
(10, 'Robson', 'dos Santos', '41434250577', '90807060501', 'Rua Das Alcacias', '1994-03-19', '105', 'Centro', 'Pindamonhangaba', 'SP', '12402560', '(12) 3642-3642', '(12) 99235-6878', 'robson@astro.com', '202cb962ac59075b964b07152d234b70', 1, 2, 1),
(11, 'Gabriela', 'Junqueira Silva', '47887478400', '15248672931', 'Av. Dr Victor Manuel', '1980-12-08', '751', 'SororÃ³', 'Pindamonhangaba', 'SP', '12498777', '(12) 3643-5574', '(12) 99155-7893', 'gabriela@astro.com', '202cb962ac59075b964b07152d234b70', 1, 1, 1),
(12, 'Leandro', 'Pereira', '41190822170', '19317283919', 'Rua dos PavÃµes', '1991-09-06', '891', 'Parque das Aves', 'Pindamonhangaba', 'SP', '12413312', '(12) 3522-1122', '(12) 99199-0099', 'leandro@astro.com', '202cb962ac59075b964b07152d234b70', 1, 3, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `informativos`
--

CREATE TABLE `informativos` (
  `ID_INFORMATIVO` int(6) NOT NULL,
  `INF_TITULO` varchar(80) DEFAULT NULL,
  `INF_CORPO` tinytext,
  `INF_LINK` varchar(80) NOT NULL,
  `TP_INFORMATIVO` int(1) NOT NULL,
  `DT_CADASTRO` datetime NOT NULL,
  `DT_VENCIMENTO` datetime NOT NULL,
  `ST_INFORMATIVO` int(1) NOT NULL,
  `ID_FUNCIONARIO` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `lancamentos`
--

CREATE TABLE `lancamentos` (
  `ID_LANCAMENTO` int(6) NOT NULL,
  `ID_TP_LANCAMENTO` int(1) NOT NULL,
  `LAN_DESCRICAO` varchar(80) DEFAULT NULL,
  `LAN_DOCUMENTO` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `lancamentos`
--

INSERT INTO `lancamentos` (`ID_LANCAMENTO`, `ID_TP_LANCAMENTO`, `LAN_DESCRICAO`, `LAN_DOCUMENTO`) VALUES
(1, 9, 'Valor que havia sido retirado do caixa para fins pessoais.', 'Dinheiro em EspÃ©cie'),
(2, 5, 'AplicaÃ§Ã£o para reserva de capital.', 'DOC-289877'),
(3, 7, 'Valor para despesas com viagem.', 'S/N'),
(4, 1, 'Adiantamento contratual.', 'CH-236176'),
(5, 2, 'TransferÃªncia referente a parcela do caminhÃ£o', 'DOC - 1321356');

-- --------------------------------------------------------

--
-- Estrutura para tabela `periodos`
--

CREATE TABLE `periodos` (
  `ID_PERIODO` int(6) NOT NULL,
  `PER_ANO` int(4) NOT NULL,
  `PER_MES` int(2) NOT NULL,
  `ST_PERIODO` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `periodos`
--

INSERT INTO `periodos` (`ID_PERIODO`, `PER_ANO`, `PER_MES`, `ST_PERIODO`) VALUES
(1, 2016, 1, 0),
(2, 2016, 2, 0),
(3, 2016, 3, 0),
(4, 2016, 4, 0),
(5, 2016, 5, 0),
(6, 2016, 6, 0),
(7, 2016, 7, 0),
(8, 2016, 8, 0),
(9, 2016, 9, 0),
(10, 2016, 10, 1),
(11, 2016, 11, 1),
(12, 2016, 12, 1),
(13, 2017, 1, 0),
(14, 2017, 2, 0),
(15, 2017, 3, 0),
(16, 2017, 4, 0),
(17, 2017, 5, 0),
(18, 2017, 6, 0),
(19, 2017, 7, 0),
(20, 2017, 8, 0),
(21, 2017, 9, 0),
(22, 2017, 10, 0),
(23, 2017, 11, 0),
(24, 2017, 12, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pessoas`
--

CREATE TABLE `pessoas` (
  `ID_PESSOA` int(6) NOT NULL,
  `PES_TP_CADASTRO` int(1) NOT NULL,
  `PES_TP_PESSOA` int(1) NOT NULL,
  `PES_DOCUMENTO` varchar(14) NOT NULL,
  `PES_NOME` varchar(80) NOT NULL,
  `PES_ENDERECO` varchar(80) NOT NULL,
  `PES_NUMERO` varchar(6) NOT NULL,
  `PES_BAIRRO` varchar(80) NOT NULL,
  `PES_CIDADE` varchar(80) NOT NULL,
  `PES_UF` char(2) NOT NULL,
  `PES_CEP` varchar(8) NOT NULL,
  `PES_CONTATO` varchar(80) DEFAULT NULL,
  `PES_FONE1` varchar(15) DEFAULT NULL,
  `PES_FONE2` varchar(15) DEFAULT NULL,
  `PES_EMAIL` varchar(80) DEFAULT NULL,
  `PES_STATUS` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `pessoas`
--

INSERT INTO `pessoas` (`ID_PESSOA`, `PES_TP_CADASTRO`, `PES_TP_PESSOA`, `PES_DOCUMENTO`, `PES_NOME`, `PES_ENDERECO`, `PES_NUMERO`, `PES_BAIRRO`, `PES_CIDADE`, `PES_UF`, `PES_CEP`, `PES_CONTATO`, `PES_FONE1`, `PES_FONE2`, `PES_EMAIL`, `PES_STATUS`) VALUES
(1, 0, 0, '40358358259829', 'CONFAB TUBOS - LTDA', 'Rua Jose Miguel', '401', 'Cidade Jardim', 'Pindamonhangaba', 'SP', '12495120', 'JosÃ© Vicente', '(12) 3522-1010', '(12) 99178-7777', 'comercial@confab.com', 1),
(2, 1, 0, '03203202000175', 'IWAMOTO AUTO-PEÃ‡AS - EPP', 'Rua Jorge TibiriÃ§a', '500', 'SÃ£o Benedito', 'Pindamonhangaba', 'SP', '12415124', 'AndrÃ© Matias', '(12) 3648-7897', '(12) 99122-9999', 'iwapecas@iwapecas.com.br', 1),
(3, 0, 0, '85857859688801', 'GERDAU AÃ‡OS - S/A', 'Rua Antonieta Severo', '307', 'Moreira Cesar', 'Pindamonhangaba', 'SP', '12595200', 'Marcela Pereira', '(12) 3050-6688', '(12) 99345-6789', 'comercial@gerdau.com', 1),
(4, 0, 0, '86868680401001', 'GV DO BRASIL - S/A', 'Rua Yamoto Jacaraiuma', '109', 'Cidade Nova', 'Pindamonhangaba', 'SP', '12495911', 'Jackson Silva', '(12) 3645-1090', '(12) 91189-9999', 'comercial@gvdobrasil.com', 1),
(5, 1, 0, '15017854000199', 'RESTAURANTE 2 IRMÃƒOS - ME', 'Av. Manoel Carlos', '514', 'Centro', 'Pindamonhangaba', 'SP', '14524588', 'Cleber', '(12) 3645-2544', '(12) 99136-7854', '2irmaos@terra.com', 1),
(6, 1, 1, '41424359501', 'Julio Gouvea da Silva', 'Rua Emilia Imediato', '304', 'MombaÃ§a', 'Pindamonhangaba', 'SP', '12495555', 'Julio (Borracheiro)', '(12) 3344-0988', '(12) 99234-5566', 'julio.gouvea1978@gmail.com', 1),
(7, 1, 0, '04062012000120', 'BARBOSA MECANICA E RETIFICA DE CAMINHOES LTDA', 'Rua Prudente de Moraes', '1677', 'Socorro', 'Pindamonhangaba', 'SP', '12400000', 'Joaquim', '(12) 3645-0000', '(12) 98122-9999', 'barbosamecanica@gmail.com', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tp_contrato`
--

CREATE TABLE `tp_contrato` (
  `ID_TP_CONTRATO` int(6) NOT NULL,
  `TPC_DESCRICAO` varchar(45) DEFAULT NULL,
  `TPC_STATUS` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `tp_contrato`
--

INSERT INTO `tp_contrato` (`ID_TP_CONTRATO`, `TPC_DESCRICAO`, `TPC_STATUS`) VALUES
(1, 'Fixado', 1),
(2, 'Quantitativo', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tp_despesas`
--

CREATE TABLE `tp_despesas` (
  `ID_TP_DESPESA` int(6) NOT NULL,
  `TPD_DESCRICAO` varchar(80) NOT NULL,
  `TPD_STATUS` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `tp_despesas`
--

INSERT INTO `tp_despesas` (`ID_TP_DESPESA`, `TPD_DESCRICAO`, `TPD_STATUS`) VALUES
(1, 'RefeiÃ§Ã£o', 1),
(2, 'CombustÃ­vel', 1),
(3, 'ManutenÃ§Ã£o de VeÃ­culos', 1),
(4, 'Material de Expediente', 1),
(5, 'Produtos de Limpeza', 1),
(6, 'Reembolso', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tp_lancamento`
--

CREATE TABLE `tp_lancamento` (
  `ID_TP_LANCAMENTO` int(2) NOT NULL,
  `TPL_DESCRICAO` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `tp_lancamento`
--

INSERT INTO `tp_lancamento` (`ID_TP_LANCAMENTO`, `TPL_DESCRICAO`) VALUES
(1, 'Cheques'),
(2, 'Encargos'),
(3, 'Estornos'),
(4, 'Tarifas'),
(5, 'Aplicacao'),
(6, 'Emprestimo/Financiamento'),
(7, 'Saque Eletronico'),
(8, 'Transferencia entre Contas'),
(9, 'Depositos'),
(10, 'Outros');

-- --------------------------------------------------------

--
-- Estrutura para tabela `transportes`
--

CREATE TABLE `transportes` (
  `ID_TRANSPORTE` int(6) NOT NULL,
  `TRA_DATA` datetime DEFAULT NULL,
  `TRA_NOTA` varchar(10) DEFAULT NULL,
  `TRA_PESO` decimal(13,2) NOT NULL,
  `TRA_OBSERVACAO` varchar(200) DEFAULT NULL,
  `ID_VEICULO` int(6) NOT NULL,
  `ID_FUNCIONARIO` int(6) NOT NULL,
  `ID_CONTRATO` int(6) NOT NULL,
  `ID_PERIODO` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `transportes`
--

INSERT INTO `transportes` (`ID_TRANSPORTE`, `TRA_DATA`, `TRA_NOTA`, `TRA_PESO`, `TRA_OBSERVACAO`, `ID_VEICULO`, `ID_FUNCIONARIO`, `ID_CONTRATO`, `ID_PERIODO`) VALUES
(1, '2016-12-06 09:03:45', 'NF-9385938', '11.60', 'Viagem realizada Ã s 09h com parada para de 45 minutos para almoÃ§o.', 2, 10, 1, 12),
(2, '2016-12-01 07:30:11', 'NF - 0005', '17.90', 'Transporte agendado para as 07:30 com pausa para o almoÃ§o', 3, 10, 3, 12),
(3, '2016-12-03 13:30:45', 'NF - 0006', '20.00', 'Viagem agendada para as 13:30 com retorno previsto para as 16:00', 2, 10, 3, 12),
(4, '2016-12-02 08:47:55', 'NF-4353588', '19.85', 'Viagem realizado durante o perÃ­odo da manhÃ£, a nota foi assinada pelo gerente.', 3, 10, 1, 12),
(5, '2016-12-07 05:00:47', 'NF - 0008', '25.13', 'Necessita de ajudante na viagem e pausa pro almoÃ§o. Agendada para as 05:00', 1, 10, 3, 12),
(6, '2016-12-08 23:47:44', 'NF - 0009', '8.97', 'Viagem agendada para as 23:00. Seguro para carga acionado.', 3, 10, 3, 12),
(7, '2016-12-09 15:27:44', 'NF - 0010', '26.87', 'Viagem agendada para as 15:00. Motorista novo em treinamento.', 3, 10, 3, 12),
(8, '2016-12-07 13:14:21', 'NF-93958', '8.90', 'Nota fiscal assinada pelo supervisor da Ã¡rea MecÃ¢nica da GV, Marcos Castro.', 1, 11, 2, 12),
(9, '2016-12-01 15:44:32', 'NF-9978767', '29.96', 'Durante a viagem o caminhÃ£o sofreu de vazamento de Ã¡gua, houve gastos com manutenÃ§Ã£o.', 2, 10, 2, 12),
(10, '2016-12-08 08:31:12', 'NF - 64894', '27.54', 'Viagem agendada para as 8:30 com pausa para almoÃ§o.', 3, 11, 2, 12),
(11, '2016-12-08 09:32:47', 'NF-9893839', '19.59', 'NecessÃ¡rio abastecer R$130,00 pois o tanque estava quase vazio.', 2, 11, 1, 12),
(12, '2016-12-09 16:58:31', 'NF - 68989', '10.08', 'Viagem agendada para o perÃ­odo da tarde.', 2, 11, 2, 12),
(13, '2016-12-08 14:32:34', 'NF-1435545', '14.76', 'Viagem realizada no perÃ­odo da tarde, foram feitas 5 viagens de ida e volta.', 1, 10, 1, 12),
(14, '2016-12-06 09:57:43', 'NF-5353536', '28.99', 'Na primeira viagem foi necessÃ¡rio esperar 40 minutos pela liberaÃ§Ã£o da empres', 3, 11, 1, 12),
(15, '2016-12-07 16:02:09', 'NF-757577', '25.55', 'A motorista Gabriela precisou aguardar das 14h atÃ© as 16h para liberaÃ§Ã£o da nota de pesagem.', 2, 11, 2, 12),
(16, '2016-12-02 11:53:49', 'NF - 001', '32.11', 'Verificado por tÃ©c. Jorge.', 3, 11, 4, 12),
(17, '2016-12-07 09:45:43', 'NF', '28.90', 'BalanÃ§a demorou 30 minutos para avaliar o peso. TÃ©cnico Toledo ciente.', 2, 10, 5, 12);

-- --------------------------------------------------------

--
-- Estrutura para tabela `veiculos`
--

CREATE TABLE `veiculos` (
  `ID_VEICULO` int(6) NOT NULL,
  `VEI_PLACA_UF` char(2) NOT NULL,
  `VEI_PLACA_MUN` varchar(80) NOT NULL,
  `VEI_PLACA_COD` char(7) NOT NULL,
  `VEI_MODELO` varchar(45) DEFAULT NULL,
  `VEI_MARCA` varchar(45) DEFAULT NULL,
  `VEI_ANO` char(4) DEFAULT NULL,
  `VEI_STATUS` int(1) NOT NULL DEFAULT '1',
  `VEI_OBSERVACAO` varchar(200) DEFAULT NULL,
  `VEI_FOTO` varchar(200) DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `veiculos`
--

INSERT INTO `veiculos` (`ID_VEICULO`, `VEI_PLACA_UF`, `VEI_PLACA_MUN`, `VEI_PLACA_COD`, `VEI_MODELO`, `VEI_MARCA`, `VEI_ANO`, `VEI_STATUS`, `VEI_OBSERVACAO`, `VEI_FOTO`) VALUES
(0, 'XX', 'XXXXX', 'XXX-999', 'XXX', 'XXX', '9999', 0, 'XXX', NULL),
(1, 'SP', 'PINDAMONHANGABA', 'FKB1030', '24250 - Semipesado', 'VOLKSWAGEN', '2014', 1, ' VeÃ­culo adquirido no ano de 2015.', '73edeb2d283d798ed5ce01d64da79671.jpg'),
(2, 'SP', 'PINDAMONHANGABA', 'BUT2399', '710 - Leve', 'Mercedes', '2010', 1, ' CaminhÃ£o com seguro pela LIBERTY.', 'a434e7fd50343a81a24033e3c6e6ac4b.jpg'),
(3, 'SP', 'PINDAMONHANGABA', 'CNV1579', 'ACTROS', 'MERCEDES BENS', '2014', 1, '', '9605e5dd90c2bfbbcc00d3874b62a6af.jpg'),
(4, 'SP', 'Pindamonhangaba', 'FBF2016', 'MB1620', 'Mercedes Benz', '2009', 0, ' VeÃ­culo de cor azul e doc. OK para serviÃ§o na GV.', 'f16f58137b8101d6a4b459acc5a535e9.jpg');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `aditivos`
--
ALTER TABLE `aditivos`
  ADD PRIMARY KEY (`ID_ADITIVO`),
  ADD KEY `ID_CONTRATO` (`ID_CONTRATO`);

--
-- Índices de tabela `baixas`
--
ALTER TABLE `baixas`
  ADD PRIMARY KEY (`ID_BAIXA`),
  ADD KEY `ID_CAIXA` (`ID_CAIXA`),
  ADD KEY `ID_FUNCIONARIO` (`ID_FUNCIONARIO`),
  ADD KEY `ID_LANCAMENTO` (`ID_LANCAMENTO`),
  ADD KEY `ID_CONTRATO` (`ID_CONTRATO`),
  ADD KEY `ID_TRANSPORTE` (`ID_TRANSPORTE`),
  ADD KEY `ID_DESPESA` (`ID_DESPESA`),
  ADD KEY `ID_PERIODO` (`ID_PERIODO`);

--
-- Índices de tabela `caixa`
--
ALTER TABLE `caixa`
  ADD PRIMARY KEY (`ID_CAIXA`),
  ADD UNIQUE KEY `CAI_CONTA` (`CAI_CONTA`),
  ADD KEY `ID_CAIXA` (`ID_CAIXA`);

--
-- Índices de tabela `caixas_saldos`
--
ALTER TABLE `caixas_saldos`
  ADD PRIMARY KEY (`ID_CAIXA_SALDO`),
  ADD KEY `ID_CAIXA` (`ID_CAIXA`);

--
-- Índices de tabela `cargos`
--
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`ID_CARGO`);

--
-- Índices de tabela `contratos`
--
ALTER TABLE `contratos`
  ADD PRIMARY KEY (`ID_CONTRATO`,`ID_TP_CONTRATO`,`ID_PESSOA`),
  ADD KEY `fk_CONTRATOS_TP_CONTRATO1_idx` (`ID_TP_CONTRATO`),
  ADD KEY `fk_CONTRATOS_PESSOAS1_idx` (`ID_PESSOA`),
  ADD KEY `ID_CONTRATO` (`ID_CONTRATO`);

--
-- Índices de tabela `despesas`
--
ALTER TABLE `despesas`
  ADD PRIMARY KEY (`ID_DESPESA`,`ID_PESSOA`,`ID_TP_DESPESA`,`ID_FUNCIONARIO`),
  ADD KEY `fk_DESPESAS_PESSOAS1_idx` (`ID_PESSOA`),
  ADD KEY `fk_DESPESAS_TP_DESPESAS1_idx` (`ID_TP_DESPESA`),
  ADD KEY `fk_DESPESAS_FUNCIONARIOS1_idx` (`ID_FUNCIONARIO`),
  ADD KEY `ID_DESPESA` (`ID_DESPESA`),
  ADD KEY `ID_VEICULO` (`ID_VEICULO`),
  ADD KEY `ID_PERIODO` (`ID_PERIODO`);

--
-- Índices de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`ID_FUNCIONARIO`,`ID_CARGO`),
  ADD UNIQUE KEY `FUN_EMAIL` (`FUN_EMAIL`),
  ADD UNIQUE KEY `FUN_CPF` (`FUN_CPF`),
  ADD UNIQUE KEY `FUN_CNH` (`FUN_CNH`),
  ADD KEY `fk_FUNCIONARIOS_CARGOS_idx` (`ID_CARGO`);

--
-- Índices de tabela `informativos`
--
ALTER TABLE `informativos`
  ADD PRIMARY KEY (`ID_INFORMATIVO`),
  ADD KEY `ID_FUNCIONARIO` (`ID_FUNCIONARIO`);

--
-- Índices de tabela `lancamentos`
--
ALTER TABLE `lancamentos`
  ADD PRIMARY KEY (`ID_LANCAMENTO`),
  ADD KEY `ID_TP_LANCAMENTO` (`ID_TP_LANCAMENTO`);

--
-- Índices de tabela `periodos`
--
ALTER TABLE `periodos`
  ADD PRIMARY KEY (`ID_PERIODO`),
  ADD KEY `ID_PERIODO` (`ID_PERIODO`);

--
-- Índices de tabela `pessoas`
--
ALTER TABLE `pessoas`
  ADD PRIMARY KEY (`ID_PESSOA`),
  ADD UNIQUE KEY `PES_DOCUMENTO` (`PES_DOCUMENTO`);

--
-- Índices de tabela `tp_contrato`
--
ALTER TABLE `tp_contrato`
  ADD PRIMARY KEY (`ID_TP_CONTRATO`);

--
-- Índices de tabela `tp_despesas`
--
ALTER TABLE `tp_despesas`
  ADD PRIMARY KEY (`ID_TP_DESPESA`);

--
-- Índices de tabela `tp_lancamento`
--
ALTER TABLE `tp_lancamento`
  ADD PRIMARY KEY (`ID_TP_LANCAMENTO`);

--
-- Índices de tabela `transportes`
--
ALTER TABLE `transportes`
  ADD PRIMARY KEY (`ID_TRANSPORTE`,`ID_VEICULO`,`ID_FUNCIONARIO`,`ID_CONTRATO`),
  ADD KEY `fk_TRANSPORTES_VEICULOS1_idx` (`ID_VEICULO`),
  ADD KEY `fk_TRANSPORTES_FUNCIONARIOS1_idx` (`ID_FUNCIONARIO`),
  ADD KEY `fk_TRANSPORTES_CONTRATOS1_idx` (`ID_CONTRATO`),
  ADD KEY `ID_TRANSPORTE` (`ID_TRANSPORTE`),
  ADD KEY `ID_PERIODO` (`ID_PERIODO`),
  ADD KEY `ID_PERIODO_2` (`ID_PERIODO`);

--
-- Índices de tabela `veiculos`
--
ALTER TABLE `veiculos`
  ADD PRIMARY KEY (`ID_VEICULO`),
  ADD UNIQUE KEY `VEI_PLACA_COD` (`VEI_PLACA_COD`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `aditivos`
--
ALTER TABLE `aditivos`
  MODIFY `ID_ADITIVO` int(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `baixas`
--
ALTER TABLE `baixas`
  MODIFY `ID_BAIXA` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT de tabela `caixa`
--
ALTER TABLE `caixa`
  MODIFY `ID_CAIXA` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `caixas_saldos`
--
ALTER TABLE `caixas_saldos`
  MODIFY `ID_CAIXA_SALDO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `cargos`
--
ALTER TABLE `cargos`
  MODIFY `ID_CARGO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de tabela `contratos`
--
ALTER TABLE `contratos`
  MODIFY `ID_CONTRATO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de tabela `despesas`
--
ALTER TABLE `despesas`
  MODIFY `ID_DESPESA` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `ID_FUNCIONARIO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de tabela `informativos`
--
ALTER TABLE `informativos`
  MODIFY `ID_INFORMATIVO` int(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `lancamentos`
--
ALTER TABLE `lancamentos`
  MODIFY `ID_LANCAMENTO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de tabela `periodos`
--
ALTER TABLE `periodos`
  MODIFY `ID_PERIODO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de tabela `pessoas`
--
ALTER TABLE `pessoas`
  MODIFY `ID_PESSOA` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de tabela `tp_contrato`
--
ALTER TABLE `tp_contrato`
  MODIFY `ID_TP_CONTRATO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `tp_despesas`
--
ALTER TABLE `tp_despesas`
  MODIFY `ID_TP_DESPESA` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `tp_lancamento`
--
ALTER TABLE `tp_lancamento`
  MODIFY `ID_TP_LANCAMENTO` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de tabela `transportes`
--
ALTER TABLE `transportes`
  MODIFY `ID_TRANSPORTE` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de tabela `veiculos`
--
ALTER TABLE `veiculos`
  MODIFY `ID_VEICULO` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `aditivos`
--
ALTER TABLE `aditivos`
  ADD CONSTRAINT `FK_CONTRATO` FOREIGN KEY (`ID_CONTRATO`) REFERENCES `contratos` (`ID_CONTRATO`);

--
-- Restrições para tabelas `baixas`
--
ALTER TABLE `baixas`
  ADD CONSTRAINT `FK_CAIXA` FOREIGN KEY (`ID_CAIXA`) REFERENCES `caixa` (`ID_CAIXA`),
  ADD CONSTRAINT `baixas_fk1` FOREIGN KEY (`ID_LANCAMENTO`) REFERENCES `lancamentos` (`ID_LANCAMENTO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `baixas_fk2` FOREIGN KEY (`ID_CONTRATO`) REFERENCES `contratos` (`ID_CONTRATO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `baixas_fk3` FOREIGN KEY (`ID_TRANSPORTE`) REFERENCES `transportes` (`ID_TRANSPORTE`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `baixas_fk4` FOREIGN KEY (`ID_DESPESA`) REFERENCES `despesas` (`ID_DESPESA`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `baixas_fk5` FOREIGN KEY (`ID_PERIODO`) REFERENCES `periodos` (`ID_PERIODO`);

--
-- Restrições para tabelas `caixas_saldos`
--
ALTER TABLE `caixas_saldos`
  ADD CONSTRAINT `FK_CAIXA_SALDO` FOREIGN KEY (`ID_CAIXA`) REFERENCES `caixa` (`ID_CAIXA`);

--
-- Restrições para tabelas `contratos`
--
ALTER TABLE `contratos`
  ADD CONSTRAINT `fk_CONTRATOS_PESSOAS1` FOREIGN KEY (`ID_PESSOA`) REFERENCES `pessoas` (`ID_PESSOA`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_CONTRATOS_TP_CONTRATO1` FOREIGN KEY (`ID_TP_CONTRATO`) REFERENCES `tp_contrato` (`ID_TP_CONTRATO`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `despesas`
--
ALTER TABLE `despesas`
  ADD CONSTRAINT `despesas_fk1` FOREIGN KEY (`ID_VEICULO`) REFERENCES `veiculos` (`ID_VEICULO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_DESPESAS_FUNCIONARIOS1` FOREIGN KEY (`ID_FUNCIONARIO`) REFERENCES `funcionarios` (`ID_FUNCIONARIO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_DESPESAS_PERIODOS` FOREIGN KEY (`ID_PERIODO`) REFERENCES `periodos` (`ID_PERIODO`),
  ADD CONSTRAINT `fk_DESPESAS_PESSOAS1` FOREIGN KEY (`ID_PESSOA`) REFERENCES `pessoas` (`ID_PESSOA`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_DESPESAS_TP_DESPESAS1` FOREIGN KEY (`ID_TP_DESPESA`) REFERENCES `tp_despesas` (`ID_TP_DESPESA`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD CONSTRAINT `fk_FUNCIONARIOS_CARGOS` FOREIGN KEY (`ID_CARGO`) REFERENCES `cargos` (`ID_CARGO`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `informativos`
--
ALTER TABLE `informativos`
  ADD CONSTRAINT `informativos_ibfk_1` FOREIGN KEY (`ID_FUNCIONARIO`) REFERENCES `funcionarios` (`ID_FUNCIONARIO`);

--
-- Restrições para tabelas `lancamentos`
--
ALTER TABLE `lancamentos`
  ADD CONSTRAINT `lancamentos_fk1` FOREIGN KEY (`ID_TP_LANCAMENTO`) REFERENCES `tp_lancamento` (`ID_TP_LANCAMENTO`);

--
-- Restrições para tabelas `transportes`
--
ALTER TABLE `transportes`
  ADD CONSTRAINT `fk_TRANSPORTES_CONTRATOS1` FOREIGN KEY (`ID_CONTRATO`) REFERENCES `contratos` (`ID_CONTRATO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_TRANSPORTES_FUNCIONARIOS1` FOREIGN KEY (`ID_FUNCIONARIO`) REFERENCES `funcionarios` (`ID_FUNCIONARIO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_TRANSPORTES_PERIODOS` FOREIGN KEY (`ID_PERIODO`) REFERENCES `periodos` (`ID_PERIODO`),
  ADD CONSTRAINT `fk_TRANSPORTES_VEICULOS1` FOREIGN KEY (`ID_VEICULO`) REFERENCES `veiculos` (`ID_VEICULO`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
